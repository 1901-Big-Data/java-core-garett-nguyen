package bigdata.projectZero;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AccountDao {
	public AccountDao() {
		
	}
	protected int viewBalance(String username) {
		int amount = 0; 
		try {
			
			Connection myConn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankaccounts", "root", "Darkflamemaster82!");							
			PreparedStatement myStat2 = myConn2.prepareStatement("Select * from Accounts where username='" + username + "'");
			ResultSet myRs2 = myStat2.executeQuery();                                              
	
			if (myRs2.next()) {
				try {
					amount = Integer.parseInt(myRs2.getString("money"));
				}
				catch (Exception b) {
					System.out.println("Input was not an integer value.");
				}
			}
			else {
				System.out.println("Account does not exist.\n");
			}
			
			myConn2.close();

			
			
		}
		catch (Exception e) {
			System.out.println("There was a problem accessing your account\n");
		}
		return amount;
	}
	protected void setBalance(String username, int finalbalance) {
		try {
			Connection myConn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankaccounts", "root", "Darkflamemaster82!");							
			PreparedStatement myStat2 = myConn2.prepareStatement("Update Accounts set money =" + finalbalance + " where username='" + username + "'");
			myStat2.executeUpdate(); 
			
			myConn2.close();
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("Could not deposit from account.");
		}
	}
	protected void deleteAccount(String username) {
		try {
			Connection myConn2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankaccounts", "root", "Darkflamemaster82!");							
			PreparedStatement myStat2 = myConn2.prepareStatement("Delete from Accounts where username='" + username + "'");
			myStat2.executeUpdate();  
			myConn2.close();
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("Could not delete account.");
		}
	}
}
